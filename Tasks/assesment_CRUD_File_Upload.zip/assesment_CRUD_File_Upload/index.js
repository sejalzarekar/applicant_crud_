const express= require('express');
const app= express();

const HOST= '127.0.0.1';
const PORT=3000;

// middleware 

// statis file access
app.use(express.static('public/'))

//req.body data access
app.use(express.urlencoded({extended:true}));

// url data access 
var url= require('url');

// db connection 
var connection = require('./config/db')

// multer declaration 
var multer = require('multer');

// configuration setup 

const storage = multer.diskStorage({
    destination:'public/uploads/',
    filename:(req, file , cb ) =>{
        cb(null, Date.now() + file.originalname);
    }
})

var upload = multer({storage : storage});

app.get('/',(req,res)=>{
    res.render('home.ejs');
})

// CREATE TABLE applicant (
//     id INT PRIMARY KEY AUTO_INCREMENT,
//     fullname VARCHAR(200),
//     email VARCHAR(200),
//     phone VARCHAR(12),
//     position VARCHAR(200),
//     resume VARCHAR(200)
// );

app.post('/saveform',upload.single('resume') ,async(req,res)=>{
    try{
    // res.send(req.body);
    // res.send(req.file);
    const {fullname, email , phone , position} = req.body;

    var resume = req.file.filename;

    var sql = `insert into applicant(fullname, email , phone , position, resume) values
    ('${fullname}','${email}','${phone}', '${position}','${resume}')
    `
    // res.send(sql);

    await connection.execute(sql);
     res.send(`
            <script>alert('Application Form submitted successfully');
            window.location.href='/'
            </script>
            `)
    }catch(err){
        console.log(err);
        res.status(500).send("Internal Server Error")
        return;
    }
})

app.get('/showapplication',async (req,res)=>{
    
        var sql = `select * from applicant`;
        const result = await connection.execute(sql);
        // console.log(result[0]);
        const obj = {data: result[0]}
        res.render('showapplication.ejs',obj);
    
})

//delete operation 

app.get('/delete/:id',async(req,res)=>{

    try{
    var id= req.params.id;
    var sql = `delete from applicant where id= ${id}`;

    await connection.execute(sql);
    res.redirect('/showapplication')

    }catch(err){
        console.log(err);
        console.log('not deleted')
    }
    
})

// edit operation 
app.get('/edit/:id',async (req,res)=>{
    var id = req.params.id;

    var sql = `select * from applicant where id='${id}'`;
    const result = await connection.execute(sql);
    console.log(result[0]);

    const obj = {data : result[0][0]};
    res.render('editapplicant.ejs', obj);
})

// POST: Update applicant
app.post('/editform', upload.single('resume'), async (req, res) => {
  try {
    const { id, fullname, email, phone, position } = req.body;
    const resume = req.file ? req.file.filename : null;

    let query;
    let values;

    if (resume) {
      query = `UPDATE applicant SET fullname = ?, email = ?, phone = ?, position = ?, resume = ? WHERE id = ?`;
      values = [fullname, email, phone, position, resume, id];
    } else {
      query = `UPDATE applicant SET fullname = ?, email = ?, phone = ?, position = ? WHERE id = ?`;
      values = [fullname, email, phone, position, id];
    }

    await connection.execute(query, values);

    res.redirect('/showapplication');
  } catch (err) {
    console.error(err);
    res.status(500).send('Data not updated due to server error.');
  }
});


app.listen(PORT,HOST,()=>{
    console.log('server is up!!');
})